CREATE TABLE Masters
(
	id SERIAL PRIMARY KEY,
	fcs VARCHAR(255),
	profile VARCHAR(255),
	phonenumber VARCHAR(255),
	photopath VARCHAR(255)
);

CREATE TABLE Applications 
( 
   id SERIAL PRIMARY KEY,
   clientphone VARCHAR(255),
   applicationdate DATE,
   enddate DATE,
   masterId INTEGER,
    constraint fk_masterid
     foreign key (MasterId) 
     REFERENCES Masters (id),
   status BOOLEAN
);

CREATE TABLE Services
(
	id SERIAL PRIMARY KEY,
	title VARCHAR(255),
	description TEXT,
	price NUMERIC(15, 2),
	execTime TIMESTAMP
);

